# Virtual-Monopoly-Deal
A virtualized version of the card game, Monopoly Deal.

## Important Info
 - Got a Main and GUI package. Main package contains the Main class for the
project, and GUI package will contain all of the screens etc.

 - Also there is an images folder to put all of the images in in the project

 - To run the program, open up cmd and type:


java -jar "path\to\Virtual-Monopoly-Deal\Virtual Monopoly Deal\dist\Virtual_Monopoly_Deal.jar"

Example: java -jar "D:\Docs\Western Stuff\Semester 4\Soft Eng I\Virtual-Monopoly-Deal\Virtual Monopoly Deal\dist\Virtual_Monopoly_Deal.jar"
